// scripts/dashboard.js

document.addEventListener('DOMContentLoaded', async () => {
  const listingsContainer = document.querySelector('#myListings');
  const swapsContainer = document.querySelector('#mySwaps');
  const pointsContainer = document.querySelector('#myPoints');

  const user = JSON.parse(localStorage.getItem('user'));
  if (!user) {
    alert('User not logged in!');
    window.location.href = 'login.html';
    return;
  }

  try {
    const res = await fetch(`/api/dashboard/${user.username}`);
    const data = await res.json();

    if (res.ok) {
      // My Listings
      data.listings.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.title} (${item.status})`;
        listingsContainer.appendChild(li);
      });

      // My Swaps
      data.swaps.forEach(swap => {
        const li = document.createElement('li');
        li.textContent = swap;
        swapsContainer.appendChild(li);
      });

      // My Points
      pointsContainer.textContent = data.points;
    } else {
      alert(data.error || 'Dashboard load failed.');
    }
  } catch (err) {
    console.error(err);
    alert('Error loading dashboard.');
  }
});
