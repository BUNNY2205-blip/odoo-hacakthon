// scripts/item.js

document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#uploadItemForm');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const formData = new FormData(form);
      const user = JSON.parse(localStorage.getItem('user'));
      if (!user) {
        alert('User not logged in');
        return;
      }

      formData.append('uploaded_by', user.username);

      const res = await fetch('/api/items', {
        method: 'POST',
        body: formData
      });

      const data = await res.json();

      if (res.ok) {
        alert('Item uploaded!');
        form.reset();
      } else {
        alert(data.error || 'Item upload failed.');
      }
    });
  }
});
