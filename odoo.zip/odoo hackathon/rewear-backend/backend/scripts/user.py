import json
import os
import hashlib

USERS_FILE = os.path.join("data", "users.json")

# Ensure the users file exists
def init_user_file():
    if not os.path.exists(USERS_FILE):
        os.makedirs(os.path.dirname(USERS_FILE), exist_ok=True)
        with open(USERS_FILE, "w") as f:
            json.dump([], f)

def read_users():
    with open(USERS_FILE, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def write_users(users):
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=2)

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# ✅ Signup Logic
def signup_user(data):
    try:
        print("📩 Received signup data:", data)
        init_user_file()
        users = read_users()

        email = data.get("email", "").strip().lower()
        name = data.get("name", "").strip()
        password = data.get("password", "")

        if not name or not email or not password:
            return {"status": "error", "message": "All fields are required"}

        if any(u["email"] == email for u in users):
            return {"status": "error", "message": "Email already registered"}

        new_user = {
            "id": len(users) + 1,
            "name": name,
            "email": email,
            "password": hash_password(password),
            "points": 10
        }

        users.append(new_user)
        write_users(users)
        print(" Registered new user:", new_user)

        return {"status": "success", "message": "User registered successfully"}

    except Exception as e:
        print("❌ Signup Error:", str(e))
        return {"status": "error", "message": "Internal server error"}

#  Login Logic
def login_user(data):
    try:
        print("🔐 Received login data:", data)
        init_user_file()
        users = read_users()

        email = data.get("email", "").strip().lower()
        password = data.get("password", "")

        if not email or not password:
            return {"status": "error", "message": "Email and password required"}

        hashed_pw = hash_password(password)

        for u in users:
            if u["email"] == email and u["password"] == hashed_pw:
                print(" Login successful for:", email)
                return {
                    "status": "success",
                    "message": "Login successful",
                    "user": {
                        "id": u["id"],
                        "name": u["name"],
                        "email": u["email"],
                        "points": u["points"]
                    }
                }

        print("❌ Invalid login attempt for:", email)
        return {"status": "error", "message": "Invalid email or password"}

    except Exception as e:
        print("❌ Login Error:", str(e))
        return {"status": "error", "message": "Internal server error"}
