import os
import json
import uuid
from werkzeug.utils import secure_filename

ITEMS_FILE = os.path.join("data", "items.json")
IMAGE_FOLDER = "images"

# Ensure items file exists
def init_items_file():
    if not os.path.exists(ITEMS_FILE):
        with open(ITEMS_FILE, "w") as f:
            json.dump([], f)

# Read all items
def read_items():
    with open(ITEMS_FILE, "r") as f:
        return json.load(f)

# Write items back to file
def write_items(items):
    with open(ITEMS_FILE, "w") as f:
        json.dump(items, f, indent=2)

# ✅ Upload New Item
def upload_item(data, image):
    init_items_file()
    items = read_items()

    item_id = len(items) + 1

    filename = secure_filename(image.filename)
    ext = filename.split('.')[-1]
    new_filename = f"{uuid.uuid4().hex}.{ext}"
    image_path = os.path.join(IMAGE_FOLDER, new_filename)
    image.save(image_path)

    new_item = {
        "id": item_id,
        "title": data.get("title"),
        "description": data.get("description"),
        "category": data.get("category"),
        "size": data.get("size"),
        "condition": data.get("condition"),
        "tags": data.get("tags"),
        "image": image_path,
        "uploader_id": int(data.get("uploader_id")),  # pass from frontend
        "is_available": True,
        "approved": True  # set True by default for now
    }

    items.append(new_item)
    write_items(items)

    return {"status": "success", "message": "Item uploaded successfully"}

#View All Approved Items
def get_items():
    init_items_file()
    items = read_items()
    return [item for item in items if item.get("approved")]
