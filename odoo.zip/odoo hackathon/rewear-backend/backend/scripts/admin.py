import json
import os

ITEMS_FILE = os.path.join(os.path.dirname(__file__), '..', 'data', 'items.json')
ITEMS_FILE = os.path.abspath(ITEMS_FILE)

def _read_items():
    if not os.path.exists(ITEMS_FILE):
        return []
    with open(ITEMS_FILE, 'r') as f:
        return json.load(f)

def _write_items(items):
    with open(ITEMS_FILE, 'w') as f:
        json.dump(items, f, indent=4)

def get_pending_items():
    items = _read_items()
    return [item for item in items if item["status"] == "pending"]

def approve_item(item_id):
    items = _read_items()
    for item in items:
        if item["id"] == item_id:
            item["status"] = "available"
            _write_items(items)
            return item
    return None

def reject_item(item_id):
    items = _read_items()
    for item in items:
        if item["id"] == item_id:
            item["status"] = "rejected"
            _write_items(items)
            return item
    return None

def remove_item(item_id):
    items = _read_items()
    updated = [item for item in items if item["id"] != item_id]
    if len(items) != len(updated):
        _write_items(updated)
        return True
    return False
