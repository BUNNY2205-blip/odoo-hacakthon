from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from backend.scripts.user import signup_user, login_user
from backend.scripts.item import upload_item, get_items
import os

# Set up correct frontend folder path
base_dir = os.path.abspath(os.path.dirname(__file__))
frontend_path = os.path.join(base_dir, "../frontend")

app = Flask(__name__, static_folder=frontend_path, static_url_path="")
CORS(app)
app.config['UPLOAD_FOLDER'] = os.path.join(base_dir, "images")

# ✅ Debug Info (helpful for verifying correct paths)
print("📁 Current working dir:", os.getcwd())
print("🌐 Serving static from:", os.path.abspath(app.static_folder))

# Serve index.html on root
@app.route("/")
def serve_index():
    return send_from_directory(app.static_folder, "index.html")

# Serve all other static assets like JS, CSS
@app.route("/<path:path>")
def serve_static(path):
    return send_from_directory(app.static_folder, path)

# API Routes
@app.route("/signup", methods=["POST"])
def signup():
    data = request.json
    if not data:
        return jsonify({"status": "error", "message": "Invalid data"}), 400
    return jsonify(signup_user(data))

@app.route("/login", methods=["POST"])
def login():
    data = request.json
    if not data:
        return jsonify({"status": "error", "message": "Invalid data"}), 400
    return jsonify(login_user(data))

@app.route("/items", methods=["GET"])
def list_items():
    return jsonify(get_items())

@app.route("/upload-item", methods=["POST"])
def upload():
    data = request.form
    image = request.files.get("image")
    if not image:
        return jsonify({"status": "error", "message": "No image uploaded"}), 400
    return jsonify(upload_item(data, image))

@app.route('/images/<filename>')
def serve_image(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# Run Flask app
if __name__ == "__main__":
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)
